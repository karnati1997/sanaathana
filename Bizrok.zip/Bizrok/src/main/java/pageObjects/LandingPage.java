package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LandingPage {
	
	public WebDriver driver;
	
	//Elements 
	//By signin=By.linkText("Login");
	//for IE 
	//By signin=By.linkText("/site/login");
	
	By signin=By.xpath("//header/div[2]/div[1]/div[1]/div[3]/div[1]/ul[1]/li[1]/a[1]");
	
	By navcart=By.xpath("//header/div[2]/div[1]/div[1]/div[3]/div[1]/ul[1]/li[3]/a[1]");
	
	By titile=By.xpath("//h2[contains(text(),'Recommended Items')]");
	
	
	public LandingPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
	}
	public WebElement getLogin() {
		return driver.findElement(signin);
		
	}
	
	
	public WebElement getnavigate() {
		// TODO Auto-generated method stub
		return driver.findElement(navcart);
		
	}
	
	public WebElement getverifytitle() {
		// TODO Auto-generated method stub
		return driver.findElement(titile);
		
	}
	
	
	
	

}
