package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {
	
	public WebDriver driver;
	
	//By username=By.linkText("Login");
	By username=By.id("loginform-username");
	By password=By.id("loginform-password");
	By Login=By.name("login-button");
	
	
	
	public LoginPage(WebDriver driver) {
		
		this.driver=driver;
	}
	
	public WebElement getusername() {
		return driver.findElement(username);
		
	}
	
	public WebElement getpassword() {
		return driver.findElement(password);
		
	}
	public WebElement getlogin() {
		return driver.findElement(Login);
		
	}

}
