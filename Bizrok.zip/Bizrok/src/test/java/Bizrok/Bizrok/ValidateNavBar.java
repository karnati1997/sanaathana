package Bizrok.Bizrok;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;

import pageObjects.LandingPage;
import resources.ExtentReporterNG;
import resources.base;

public class ValidateNavBar  extends base {
	public WebDriver driver;
	@BeforeTest
	public void initilize() throws IOException{
		driver=initializeDriver();
		
		driver.get(prop.getProperty("url"));
		
	}
	
	@Test
	
	//ExtentReports extent=ExtentReporterNG.getReportObject();
	
	public void navigate() {
		
		LandingPage l=new LandingPage(driver);
		
		//compare the text from the browser with actual text.- Error..
	    Assert.assertTrue(l.getnavigate().isDisplayed());
		System.out.println("Assertion is compleated");
	}

	@AfterTest
	public void teardown() {
		
		driver.quit();
		
	}
}
