package Bizrok.Bizrok;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageObjects.LandingPage;
import resources.base;

public class ValidateTitle extends base {
	
	@BeforeTest
	public void initilize() throws IOException {
		
        driver=initializeDriver();
		
		driver.get(prop.getProperty("url"));
		
	}
	
	@Test
	public void verifytitle() {
		
		
		LandingPage l=new LandingPage(driver);
	
		Assert.assertEquals(l.getverifytitle().getText(), "RECOMMENDED ITEMS");
		System.out.println("Assertion pass");
	}
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}

}
