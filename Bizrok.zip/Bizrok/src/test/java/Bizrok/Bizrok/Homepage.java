package Bizrok.Bizrok;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pageObjects.LandingPage;
import pageObjects.LoginPage;
import resources.base;

public class Homepage extends base {
	
	
	
	//public WebDriver WebDriver;


	@BeforeTest
	public void initilize() throws IOException{
		driver=initializeDriver();
		//driver.get("http://sanaathana.org/");
		driver.get(prop.getProperty("url"));
		
		/*String url = WebDriver.getCurrentUrl();
		if(url == "http://sanaathana.org/")
		{
		    // take screenshoot
		}

		Assert.assertEquals(url, "http://sanaathana.org/");*/
		
	}
	
	@Test(dataProvider="getData")
	public void basepageNavigation(String username,String password) throws IOException, Exception {
		
		
		
		LandingPage l=new LandingPage(driver);
		//l.getLogin().click();
		
		WebDriverWait wait = new WebDriverWait(driver, 30);
		WebElement el = wait.until(ExpectedConditions.elementToBeClickable(l.getLogin()));
		el.click();
		
		/*WebElement element = driver.findElement(By.xpath("//header/div[2]/div[1]/div[1]/div[3]/div[1]/ul[1]/li[1]/a[1]"));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", element);*/
		
		
		//login page
		LoginPage lp= new LoginPage(driver);
		lp.getusername().sendKeys(username);
		lp.getpassword().sendKeys(password);
		
		lp.getlogin().click();
		
		
		
			
	}
	
	@AfterTest
	public void teardown(){
		
		driver.quit();
		
	}
	
	
	  @DataProvider 
	  public Object[][] getData() { 
		  // Row stands for how many different data types test should run 
		  //coloumn stands for how many values per each test
	  
	  // Array size is 2
	// 0,1 
		  
   Object[][] data=new Object[1][2]; 
      //0th row
	  data[0][0]="chandra";
	  data[0][1]="123456";
	
	  
	  return data;
	  
	  }
	 


}
